from app import create_app

app = create_app()

if __name__ == '__main__':
    print("\n" + "="*50)
    print("  OfficeSuite — Office Management System")
    print("="*50)
    print("  URL: http://127.0.0.1:5000")
    print("  Login: admin / admin123")
    print("="*50 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000)
