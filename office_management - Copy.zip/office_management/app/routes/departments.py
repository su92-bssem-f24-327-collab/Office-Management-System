from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from functools import wraps

departments_bp = Blueprint('departments', __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated


def get_db():
    return current_app.get_db()


@departments_bp.route('/departments')
@login_required
def index():
    db = get_db()
    search = request.args.get('search', '').strip()
    if search:
        departments = db.execute(
            """SELECT d.*, COUNT(e.id) as employee_count 
               FROM departments d LEFT JOIN employees e ON d.id=e.department_id
               WHERE d.name LIKE ? OR d.manager_name LIKE ?
               GROUP BY d.id ORDER BY d.name""",
            (f'%{search}%', f'%{search}%')
        ).fetchall()
    else:
        departments = db.execute(
            """SELECT d.*, COUNT(e.id) as employee_count 
               FROM departments d LEFT JOIN employees e ON d.id=e.department_id
               GROUP BY d.id ORDER BY d.name"""
        ).fetchall()
    return render_template('departments.html', departments=departments, search=search)


@departments_bp.route('/departments/add', methods=['GET', 'POST'])
@admin_required
def add():
    if request.method == 'POST':
        db = get_db()
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        manager_name = request.form.get('manager_name', '').strip()

        if not name:
            flash('Department name is required.', 'danger')
        else:
            existing = db.execute("SELECT id FROM departments WHERE name=?", (name,)).fetchone()
            if existing:
                flash('Department name already exists.', 'danger')
            else:
                db.execute(
                    "INSERT INTO departments (name, description, manager_name) VALUES (?,?,?)",
                    (name, description, manager_name)
                )
                db.commit()
                flash('Department added successfully!', 'success')
                return redirect(url_for('departments.index'))

    return render_template('department_form.html', department=None, action='Add')


@departments_bp.route('/departments/edit/<int:dept_id>', methods=['GET', 'POST'])
@admin_required
def edit(dept_id):
    db = get_db()
    department = db.execute("SELECT * FROM departments WHERE id=?", (dept_id,)).fetchone()
    if not department:
        flash('Department not found.', 'danger')
        return redirect(url_for('departments.index'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        manager_name = request.form.get('manager_name', '').strip()

        if not name:
            flash('Department name is required.', 'danger')
        else:
            db.execute(
                "UPDATE departments SET name=?, description=?, manager_name=? WHERE id=?",
                (name, description, manager_name, dept_id)
            )
            db.commit()
            flash('Department updated successfully!', 'success')
            return redirect(url_for('departments.index'))

    return render_template('department_form.html', department=department, action='Edit')


@departments_bp.route('/departments/delete/<int:dept_id>', methods=['POST'])
@admin_required
def delete(dept_id):
    db = get_db()
    db.execute("DELETE FROM departments WHERE id=?", (dept_id,))
    db.commit()
    flash('Department deleted.', 'success')
    return redirect(url_for('departments.index'))
