from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from functools import wraps
from datetime import date

attendance_bp = Blueprint('attendance', __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated


def get_db():
    return current_app.get_db()


@attendance_bp.route('/attendance')
@login_required
def index():
    db = get_db()
    selected_date = request.args.get('date', date.today().strftime('%Y-%m-%d'))
    search = request.args.get('search', '').strip()

    query = """SELECT a.*, e.full_name, e.position, d.name as dept_name
               FROM attendance a 
               JOIN employees e ON a.employee_id=e.id
               LEFT JOIN departments d ON e.department_id=d.id
               WHERE a.date=?"""
    params = [selected_date]
    if search:
        query += " AND (e.full_name LIKE ? OR e.position LIKE ?)"
        params.extend([f'%{search}%', f'%{search}%'])
    query += " ORDER BY e.full_name"

    records = db.execute(query, params).fetchall()

    # Stats for selected date
    total = db.execute("SELECT COUNT(*) FROM employees WHERE status='active'").fetchone()[0]
    present = db.execute("SELECT COUNT(*) FROM attendance WHERE date=? AND status='present'", (selected_date,)).fetchone()[0]
    absent = db.execute("SELECT COUNT(*) FROM attendance WHERE date=? AND status='absent'", (selected_date,)).fetchone()[0]

    employees = db.execute("SELECT * FROM employees WHERE status='active' ORDER BY full_name").fetchall()
    return render_template('attendance.html',
        records=records, employees=employees,
        selected_date=selected_date, search=search,
        total=total, present=present, absent=absent
    )


@attendance_bp.route('/attendance/mark', methods=['POST'])
@admin_required
def mark():
    db = get_db()
    employee_id = request.form.get('employee_id')
    att_date = request.form.get('date', date.today().strftime('%Y-%m-%d'))
    status = request.form.get('status', 'present')
    notes = request.form.get('notes', '').strip()

    if not employee_id:
        flash('Employee is required.', 'danger')
        return redirect(url_for('attendance.index'))

    existing = db.execute(
        "SELECT id FROM attendance WHERE employee_id=? AND date=?", (employee_id, att_date)
    ).fetchone()

    if existing:
        db.execute(
            "UPDATE attendance SET status=?, notes=? WHERE employee_id=? AND date=?",
            (status, notes, employee_id, att_date)
        )
        flash('Attendance updated.', 'success')
    else:
        db.execute(
            "INSERT INTO attendance (employee_id, date, status, notes) VALUES (?,?,?,?)",
            (employee_id, att_date, status, notes)
        )
        flash('Attendance marked successfully!', 'success')
    db.commit()
    return redirect(url_for('attendance.index', date=att_date))


@attendance_bp.route('/attendance/delete/<int:att_id>', methods=['POST'])
@admin_required
def delete(att_id):
    db = get_db()
    rec = db.execute("SELECT date FROM attendance WHERE id=?", (att_id,)).fetchone()
    db.execute("DELETE FROM attendance WHERE id=?", (att_id,))
    db.commit()
    flash('Attendance record deleted.', 'success')
    redirect_date = rec['date'] if rec else date.today().strftime('%Y-%m-%d')
    return redirect(url_for('attendance.index', date=redirect_date))
