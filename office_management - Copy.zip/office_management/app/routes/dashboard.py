from flask import Blueprint, render_template, session, redirect, url_for, current_app
from datetime import date
from functools import wraps

dashboard_bp = Blueprint('dashboard', __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def get_db():
    return current_app.get_db()


@dashboard_bp.route('/dashboard')
@login_required
def index():
    db = get_db()
    today = date.today().strftime('%Y-%m-%d')

    total_employees = db.execute("SELECT COUNT(*) FROM employees WHERE status='active'").fetchone()[0]
    today_present = db.execute(
        "SELECT COUNT(*) FROM attendance WHERE date=? AND status='present'", (today,)
    ).fetchone()[0]
    total_tasks = db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
    total_departments = db.execute("SELECT COUNT(*) FROM departments").fetchone()[0]

    # Task distribution for pie chart
    task_stats = db.execute(
        "SELECT status, COUNT(*) as count FROM tasks GROUP BY status"
    ).fetchall()
    task_labels = [r['status'].replace('_', ' ').title() for r in task_stats]
    task_counts = [r['count'] for r in task_stats]

    # Weekly attendance for line chart
    from datetime import timedelta
    weekly_labels = []
    weekly_present = []
    weekly_absent = []
    for i in range(6, -1, -1):
        day = (date.today() - timedelta(days=i)).strftime('%Y-%m-%d')
        label = (date.today() - timedelta(days=i)).strftime('%a')
        weekly_labels.append(label)
        p = db.execute("SELECT COUNT(*) FROM attendance WHERE date=? AND status='present'", (day,)).fetchone()[0]
        a = db.execute("SELECT COUNT(*) FROM attendance WHERE date=? AND status='absent'", (day,)).fetchone()[0]
        weekly_present.append(p)
        weekly_absent.append(a)

    # Recent tasks
    recent_tasks = db.execute(
        """SELECT t.*, e.full_name as employee_name 
           FROM tasks t LEFT JOIN employees e ON t.assigned_to=e.id 
           ORDER BY t.created_at DESC LIMIT 5"""
    ).fetchall()

    # Recent employees
    recent_employees = db.execute(
        """SELECT e.*, d.name as dept_name 
           FROM employees e LEFT JOIN departments d ON e.department_id=d.id 
           ORDER BY e.created_at DESC LIMIT 5"""
    ).fetchall()

    return render_template('dashboard.html',
        total_employees=total_employees,
        today_present=today_present,
        total_tasks=total_tasks,
        total_departments=total_departments,
        task_labels=task_labels,
        task_counts=task_counts,
        weekly_labels=weekly_labels,
        weekly_present=weekly_present,
        weekly_absent=weekly_absent,
        recent_tasks=recent_tasks,
        recent_employees=recent_employees
    )
