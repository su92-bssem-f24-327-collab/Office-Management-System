from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from functools import wraps

tasks_bp = Blueprint('tasks', __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated


def get_db():
    return current_app.get_db()


@tasks_bp.route('/tasks')
@login_required
def index():
    db = get_db()
    search = request.args.get('search', '').strip()
    status_filter = request.args.get('status', '').strip()

    query = """SELECT t.*, e.full_name as employee_name 
               FROM tasks t LEFT JOIN employees e ON t.assigned_to=e.id WHERE 1=1"""
    params = []

    if search:
        query += " AND (t.title LIKE ? OR t.description LIKE ?)"
        params.extend([f'%{search}%', f'%{search}%'])
    if status_filter:
        query += " AND t.status=?"
        params.append(status_filter)

    query += " ORDER BY t.created_at DESC"
    tasks = db.execute(query, params).fetchall()
    employees = db.execute("SELECT * FROM employees WHERE status='active' ORDER BY full_name").fetchall()
    return render_template('tasks.html', tasks=tasks, employees=employees, search=search, status_filter=status_filter)


@tasks_bp.route('/tasks/add', methods=['GET', 'POST'])
@admin_required
def add():
    db = get_db()
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        assigned_to = request.form.get('assigned_to') or None
        priority = request.form.get('priority', 'medium')
        status = request.form.get('status', 'pending')
        due_date = request.form.get('due_date', '').strip()

        if not title:
            flash('Task title is required.', 'danger')
        else:
            db.execute(
                "INSERT INTO tasks (title, description, assigned_to, priority, status, due_date, created_by) VALUES (?,?,?,?,?,?,?)",
                (title, description, assigned_to, priority, status, due_date or None, session['user_id'])
            )
            db.commit()
            flash('Task added successfully!', 'success')
            return redirect(url_for('tasks.index'))

    employees = db.execute("SELECT * FROM employees WHERE status='active' ORDER BY full_name").fetchall()
    return render_template('task_form.html', employees=employees, task=None, action='Add')


@tasks_bp.route('/tasks/edit/<int:task_id>', methods=['GET', 'POST'])
@admin_required
def edit(task_id):
    db = get_db()
    task = db.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    if not task:
        flash('Task not found.', 'danger')
        return redirect(url_for('tasks.index'))

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        assigned_to = request.form.get('assigned_to') or None
        priority = request.form.get('priority', 'medium')
        status = request.form.get('status', 'pending')
        due_date = request.form.get('due_date', '').strip()

        if not title:
            flash('Task title is required.', 'danger')
        else:
            from datetime import date
            db.execute(
                "UPDATE tasks SET title=?, description=?, assigned_to=?, priority=?, status=?, due_date=?, updated_at=? WHERE id=?",
                (title, description, assigned_to, priority, status, due_date or None, date.today().strftime('%Y-%m-%d'), task_id)
            )
            db.commit()
            flash('Task updated successfully!', 'success')
            return redirect(url_for('tasks.index'))

    employees = db.execute("SELECT * FROM employees WHERE status='active' ORDER BY full_name").fetchall()
    return render_template('task_form.html', employees=employees, task=task, action='Edit')


@tasks_bp.route('/tasks/delete/<int:task_id>', methods=['POST'])
@admin_required
def delete(task_id):
    db = get_db()
    db.execute("DELETE FROM tasks WHERE id=?", (task_id,))
    db.commit()
    flash('Task deleted.', 'success')
    return redirect(url_for('tasks.index'))
