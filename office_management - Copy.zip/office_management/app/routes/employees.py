from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from functools import wraps

employees_bp = Blueprint('employees', __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated


def get_db():
    return current_app.get_db()


@employees_bp.route('/employees')
@login_required
def index():
    db = get_db()
    search = request.args.get('search', '').strip()
    if search:
        employees = db.execute(
            """SELECT e.*, d.name as dept_name FROM employees e 
               LEFT JOIN departments d ON e.department_id=d.id
               WHERE e.full_name LIKE ? OR e.email LIKE ? OR e.position LIKE ?
               ORDER BY e.full_name""",
            (f'%{search}%', f'%{search}%', f'%{search}%')
        ).fetchall()
    else:
        employees = db.execute(
            """SELECT e.*, d.name as dept_name FROM employees e 
               LEFT JOIN departments d ON e.department_id=d.id
               ORDER BY e.full_name"""
        ).fetchall()
    departments = db.execute("SELECT * FROM departments ORDER BY name").fetchall()
    return render_template('employees.html', employees=employees, departments=departments, search=search)


@employees_bp.route('/employees/add', methods=['GET', 'POST'])
@admin_required
def add():
    db = get_db()
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        department_id = request.form.get('department_id') or None
        position = request.form.get('position', '').strip()
        hire_date = request.form.get('hire_date', '').strip()
        status = request.form.get('status', 'active')

        if not full_name or not email:
            flash('Name and email are required.', 'danger')
        else:
            existing = db.execute("SELECT id FROM employees WHERE email=?", (email,)).fetchone()
            if existing:
                flash('Email already exists.', 'danger')
            else:
                db.execute(
                    "INSERT INTO employees (full_name, email, phone, department_id, position, hire_date, status) VALUES (?,?,?,?,?,?,?)",
                    (full_name, email, phone, department_id, position, hire_date or None, status)
                )
                db.commit()
                flash('Employee added successfully!', 'success')
                return redirect(url_for('employees.index'))

    departments = db.execute("SELECT * FROM departments ORDER BY name").fetchall()
    return render_template('employee_form.html', departments=departments, employee=None, action='Add')


@employees_bp.route('/employees/edit/<int:emp_id>', methods=['GET', 'POST'])
@admin_required
def edit(emp_id):
    db = get_db()
    employee = db.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if not employee:
        flash('Employee not found.', 'danger')
        return redirect(url_for('employees.index'))

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        department_id = request.form.get('department_id') or None
        position = request.form.get('position', '').strip()
        hire_date = request.form.get('hire_date', '').strip()
        status = request.form.get('status', 'active')

        if not full_name or not email:
            flash('Name and email are required.', 'danger')
        else:
            db.execute(
                "UPDATE employees SET full_name=?, email=?, phone=?, department_id=?, position=?, hire_date=?, status=? WHERE id=?",
                (full_name, email, phone, department_id, position, hire_date or None, status, emp_id)
            )
            db.commit()
            flash('Employee updated successfully!', 'success')
            return redirect(url_for('employees.index'))

    departments = db.execute("SELECT * FROM departments ORDER BY name").fetchall()
    return render_template('employee_form.html', departments=departments, employee=employee, action='Edit')


@employees_bp.route('/employees/delete/<int:emp_id>', methods=['POST'])
@admin_required
def delete(emp_id):
    db = get_db()
    db.execute("DELETE FROM employees WHERE id=?", (emp_id,))
    db.commit()
    flash('Employee deleted.', 'success')
    return redirect(url_for('employees.index'))
