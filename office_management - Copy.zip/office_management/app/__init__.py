import os
import sqlite3
from flask import Flask, g
from datetime import date


def get_db(app):
    def _get_db():
        if 'db' not in g:
            g.db = sqlite3.connect(
                app.config['DATABASE'],
                detect_types=sqlite3.PARSE_DECLTYPES
            )
            g.db.row_factory = sqlite3.Row
        return g.db
    return _get_db


def create_app():
    app = Flask(__name__, template_folder='../templates', static_folder='../static')
    app.secret_key = 'office-mgmt-secret-2024-xK9pL'

    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    app.config['DATABASE'] = os.path.join(BASE_DIR, 'database', 'office.db')

    # Attach get_db to app
    app.get_db = get_db(app)

    @app.teardown_appcontext
    def close_db(error):
        db = g.pop('db', None)
        if db is not None:
            db.close()

    @app.context_processor
    def inject_globals():
        return {
            'current_date': date.today().strftime('%B %d, %Y'),
            'current_year': date.today().year
        }

    # Init DB
    with app.app_context():
        init_db(app)

    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.employees import employees_bp
    from app.routes.departments import departments_bp
    from app.routes.tasks import tasks_bp
    from app.routes.attendance import attendance_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(employees_bp)
    app.register_blueprint(departments_bp)
    app.register_blueprint(tasks_bp)
    app.register_blueprint(attendance_bp)

    return app


def init_db(app):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    schema_path = os.path.join(BASE_DIR, 'database', 'schema.sql')
    db_path = app.config['DATABASE']

    conn = sqlite3.connect(db_path)
    with open(schema_path, 'r') as f:
        conn.executescript(f.read())
    conn.commit()

    # Seed default admin if not exists
    cursor = conn.execute("SELECT COUNT(*) FROM users WHERE role='admin'")
    if cursor.fetchone()[0] == 0:
        from werkzeug.security import generate_password_hash
        conn.execute(
            "INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?,?)",
            ('admin', 'admin@office.com', generate_password_hash('admin123'), 'admin')
        )
        # Seed departments
        departments = [
            ('Engineering', 'Software development and infrastructure', 'Alice Johnson'),
            ('Human Resources', 'Recruitment and employee management', 'Bob Smith'),
            ('Marketing', 'Brand and digital marketing', 'Carol Davis'),
            ('Finance', 'Accounting and financial planning', 'David Lee'),
        ]
        conn.executemany(
            "INSERT INTO departments (name, description, manager_name) VALUES (?,?,?)",
            departments
        )
        conn.commit()
        # Seed employees
        from datetime import date, timedelta
        import random
        employees = [
            ('Sarah Connor', 'sarah@office.com', '555-0101', 1, 'Senior Developer', '2022-03-15', 'active'),
            ('James Wilson', 'james@office.com', '555-0102', 1, 'Junior Developer', '2023-06-01', 'active'),
            ('Emily Clark', 'emily@office.com', '555-0103', 2, 'HR Manager', '2021-09-10', 'active'),
            ('Michael Brown', 'michael@office.com', '555-0104', 3, 'Marketing Lead', '2022-11-20', 'active'),
            ('Jessica Taylor', 'jessica@office.com', '555-0105', 4, 'Accountant', '2023-01-05', 'active'),
            ('Robert Martinez', 'robert@office.com', '555-0106', 1, 'DevOps Engineer', '2022-07-18', 'active'),
            ('Linda Anderson', 'linda@office.com', '555-0107', 2, 'Recruiter', '2023-04-22', 'active'),
            ('Daniel Thomas', 'daniel@office.com', '555-0108', 3, 'Content Writer', '2023-08-30', 'active'),
        ]
        conn.executemany(
            "INSERT INTO employees (full_name, email, phone, department_id, position, hire_date, status) VALUES (?,?,?,?,?,?,?)",
            employees
        )
        conn.commit()
        # Seed tasks
        tasks = [
            ('Build REST API', 'Develop REST endpoints for mobile app', 1, 'high', 'in_progress', '2024-12-31', 1),
            ('Redesign Landing Page', 'Update company landing page design', 4, 'medium', 'pending', '2024-12-15', 1),
            ('Q4 Financial Report', 'Prepare quarterly financial statements', 5, 'urgent', 'pending', '2024-12-10', 1),
            ('Onboard New Hires', 'Orientation for December batch', 3, 'medium', 'completed', '2024-11-30', 1),
            ('Server Migration', 'Migrate production servers to AWS', 6, 'urgent', 'in_progress', '2024-12-20', 1),
            ('Social Media Campaign', 'Run holiday marketing campaign', 4, 'high', 'pending', '2024-12-25', 1),
            ('Code Review Process', 'Document code review guidelines', 1, 'low', 'completed', '2024-11-20', 1),
            ('Recruitment Drive', 'Hire 5 new engineers Q1', 3, 'high', 'pending', '2025-01-15', 1),
        ]
        conn.executemany(
            "INSERT INTO tasks (title, description, assigned_to, priority, status, due_date, created_by) VALUES (?,?,?,?,?,?,?)",
            tasks
        )
        conn.commit()
        # Seed attendance for last 7 days
        today = date.today()
        statuses = ['present', 'present', 'present', 'present', 'absent']
        for i in range(7):
            day = (today - timedelta(days=i)).strftime('%Y-%m-%d')
            for emp_id in range(1, 9):
                status = random.choice(statuses)
                try:
                    conn.execute(
                        "INSERT INTO attendance (employee_id, date, status) VALUES (?,?,?)",
                        (emp_id, day, status)
                    )
                except:
                    pass
        conn.commit()
    conn.close()
