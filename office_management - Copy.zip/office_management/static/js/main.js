// ===== THEME MANAGEMENT =====
function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    const icon = document.getElementById('themeIcon');
    if (icon) {
        icon.className = theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
    }
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    applyTheme(current === 'dark' ? 'light' : 'dark');
}

// Apply saved theme immediately
(function() {
    const saved = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
})();

// ===== SIDEBAR MANAGEMENT =====
let sidebarCollapsed = localStorage.getItem('sidebar') === 'collapsed';

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const main = document.getElementById('mainContent');
    const overlay = document.getElementById('sidebarOverlay');
    if (!sidebar) return;

    const isMobile = window.innerWidth <= 768;

    if (isMobile) {
        sidebar.classList.toggle('mobile-open');
        overlay.classList.toggle('active');
    } else {
        sidebarCollapsed = !sidebarCollapsed;
        sidebar.classList.toggle('collapsed', sidebarCollapsed);
        main.classList.toggle('expanded', sidebarCollapsed);
        localStorage.setItem('sidebar', sidebarCollapsed ? 'collapsed' : 'expanded');
    }
}

// ===== INIT ON DOM LOAD =====
document.addEventListener('DOMContentLoaded', function() {
    // Apply theme icon
    const saved = localStorage.getItem('theme') || 'light';
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = saved === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';

    // Restore sidebar state
    const sidebar = document.getElementById('sidebar');
    const main = document.getElementById('mainContent');
    if (sidebar && main && window.innerWidth > 768) {
        if (sidebarCollapsed) {
            sidebar.classList.add('collapsed');
            main.classList.add('expanded');
        }
    }

    // Auto dismiss flash alerts
    setTimeout(() => {
        document.querySelectorAll('.flash-alert').forEach(el => {
            el.classList.remove('show');
            setTimeout(() => el.remove(), 300);
        });
    }, 4000);

    // Table sorting
    document.querySelectorAll('.advanced-table thead th').forEach(th => {
        th.addEventListener('click', () => sortTable(th));
    });
});

// ===== DELETE CONFIRMATION =====
function confirmDelete(url, name) {
    document.getElementById('deleteItemName').textContent = name;
    document.getElementById('deleteForm').action = url;
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}

// ===== TABLE SORTING =====
function sortTable(th) {
    const table = th.closest('table');
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const idx = Array.from(th.parentElement.children).indexOf(th);
    const asc = th.dataset.sortDir !== 'asc';
    th.dataset.sortDir = asc ? 'asc' : 'desc';

    // Reset other headers
    th.closest('thead').querySelectorAll('th').forEach(h => {
        if (h !== th) delete h.dataset.sortDir;
    });

    rows.sort((a, b) => {
        const aText = a.cells[idx]?.textContent.trim().toLowerCase() || '';
        const bText = b.cells[idx]?.textContent.trim().toLowerCase() || '';
        return asc ? aText.localeCompare(bText) : bText.localeCompare(aText);
    });

    rows.forEach(r => tbody.appendChild(r));
}

// ===== RESIZE HANDLER =====
window.addEventListener('resize', () => {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (!sidebar) return;
    if (window.innerWidth > 768) {
        sidebar.classList.remove('mobile-open');
        if (overlay) overlay.classList.remove('active');
    }
});
