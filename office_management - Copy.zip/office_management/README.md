# OfficeSuite — Office Management System

A modern, production-quality Office Management System built with Flask + SQLite.

## Features
- Role-based authentication (Admin / Employee)
- Employee CRUD management
- Department management
- Task assignment with priorities & status tracking
- Attendance tracking
- Real-time dashboard with charts
- Dark/Light mode toggle
- Responsive sidebar
- Advanced tables with search & sort

## Quick Start

### 1. Prerequisites
- Python 3.8 or higher
- pip

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the app
```bash
python run.py
```

### 4. Open in browser
```
http://127.0.0.1:5000
```

### 5. Default Login
| Field    | Value       |
|----------|-------------|
| Username | admin       |
| Password | admin123    |

## Project Structure
```
office_management/
├── app/
│   ├── __init__.py          # App factory
│   └── routes/              # Blueprints
│       ├── auth.py
│       ├── dashboard.py
│       ├── employees.py
│       ├── departments.py
│       ├── tasks.py
│       └── attendance.py
├── templates/               # HTML templates
├── static/                  # CSS, JS, images
│   ├── css/style.css
│   └── js/main.js
├── database/
│   ├── schema.sql
│   └── office.db            # Auto-created on first run
├── run.py
├── requirements.txt
└── README.md
```

## Tech Stack
- **Backend**: Flask 3.0 + Python
- **Database**: SQLite
- **Frontend**: Bootstrap 5 + Chart.js + FontAwesome
- **Auth**: Werkzeug password hashing + Flask sessions
